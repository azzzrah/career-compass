import { supabase } from '@/integrations/supabase/client';

export async function seedDatabase() {
  // Seed jobs
  const jobs = [
    {
      title: 'Frontend Developer',
      company: 'TechCorp SG',
      salary_range: '$4,000 - $6,000',
      location: 'Singapore',
      source: 'MyCareersFuture',
      required_skills: ['React', 'TypeScript', 'CSS', 'Node.js'],
      description: 'We are looking for a talented Frontend Developer to join our growing team. You will be responsible for building user-facing features using React and TypeScript.',
    },
    {
      title: 'Full Stack Engineer',
      company: 'StartupX',
      salary_range: '$5,500 - $8,000',
      location: 'Singapore',
      source: 'LinkedIn',
      required_skills: ['React', 'Node.js', 'PostgreSQL', 'AWS', 'Docker'],
      description: 'Join our fast-paced startup as a Full Stack Engineer. Work on cutting-edge technology and help build products that impact millions of users.',
    },
    {
      title: 'Backend Developer',
      company: 'FinTech Solutions',
      salary_range: '$5,000 - $7,500',
      location: 'Singapore',
      source: 'MyCareersFuture',
      required_skills: ['Python', 'AWS', 'PostgreSQL', 'Docker', 'Kubernetes'],
      description: 'FinTech Solutions is seeking a Backend Developer to help build scalable financial systems. Strong problem-solving skills required.',
    },
    {
      title: 'Junior Software Engineer',
      company: 'InnovateTech',
      salary_range: '$3,500 - $4,500',
      location: 'Singapore',
      source: 'Indeed',
      required_skills: ['JavaScript', 'React', 'Git'],
      description: 'Perfect opportunity for fresh graduates! Learn from experienced engineers and grow your skills in a supportive environment.',
    },
    {
      title: 'DevOps Engineer',
      company: 'CloudFirst',
      salary_range: '$6,000 - $9,000',
      location: 'Singapore',
      source: 'LinkedIn',
      required_skills: ['AWS', 'Docker', 'Kubernetes', 'Terraform', 'Python'],
      description: 'Help us build and maintain our cloud infrastructure. Experience with CI/CD pipelines and container orchestration is a plus.',
    },
  ];

  const { error: jobsError } = await supabase.from('jobs').insert(jobs);
  if (jobsError) throw jobsError;

  // Seed courses
  const courses = [
    {
      skill_tag: 'React',
      title: 'React - The Complete Guide',
      provider: 'Udemy',
      url: 'https://www.udemy.com/course/react-the-complete-guide/',
    },
    {
      skill_tag: 'TypeScript',
      title: 'Understanding TypeScript',
      provider: 'Udemy',
      url: 'https://www.udemy.com/course/understanding-typescript/',
    },
    {
      skill_tag: 'AWS',
      title: 'AWS Certified Solutions Architect',
      provider: 'Coursera',
      url: 'https://www.coursera.org/learn/aws-certified-solutions-architect',
    },
    {
      skill_tag: 'Docker',
      title: 'Docker for Developers',
      provider: 'LinkedIn Learning',
      url: 'https://www.linkedin.com/learning/docker-for-developers',
    },
    {
      skill_tag: 'Python',
      title: 'Python for Everybody',
      provider: 'Coursera',
      url: 'https://www.coursera.org/specializations/python',
    },
    {
      skill_tag: 'Node.js',
      title: 'The Complete Node.js Developer Course',
      provider: 'Udemy',
      url: 'https://www.udemy.com/course/the-complete-nodejs-developer-course/',
    },
    {
      skill_tag: 'PostgreSQL',
      title: 'PostgreSQL Bootcamp',
      provider: 'Udemy',
      url: 'https://www.udemy.com/course/postgresql-bootcamp/',
    },
    {
      skill_tag: 'Kubernetes',
      title: 'Kubernetes for Beginners',
      provider: 'Coursera',
      url: 'https://www.coursera.org/learn/kubernetes-for-beginners',
    },
  ];

  const { error: coursesError } = await supabase.from('courses').insert(courses);
  if (coursesError) throw coursesError;

  return { success: true };
}
