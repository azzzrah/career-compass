export interface SkillAnalysis {
  matchScore: number;
  matchedSkills: string[];
  missingSkills: string[];
}

export function analyzeSkillGap(
  userSkills: string[],
  requiredSkills: string[]
): SkillAnalysis {
  const normalizedUserSkills = userSkills.map(s => s.toLowerCase().trim());
  const normalizedRequiredSkills = requiredSkills.map(s => s.toLowerCase().trim());

  const matchedSkills: string[] = [];
  const missingSkills: string[] = [];

  requiredSkills.forEach((skill, index) => {
    if (normalizedUserSkills.includes(normalizedRequiredSkills[index])) {
      matchedSkills.push(skill);
    } else {
      missingSkills.push(skill);
    }
  });

  const matchScore = requiredSkills.length > 0
    ? Math.round((matchedSkills.length / requiredSkills.length) * 100)
    : 100;

  return {
    matchScore,
    matchedSkills,
    missingSkills,
  };
}

export function getMatchScoreColor(score: number): 'high' | 'medium' | 'low' {
  if (score >= 80) return 'high';
  if (score >= 50) return 'medium';
  return 'low';
}
