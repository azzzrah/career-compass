import { useMemo } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { RoadmapTimeline } from '@/components/roadmap/RoadmapTimeline';
import { useProfile } from '@/hooks/useProfile';
import { useJobs } from '@/hooks/useJobs';
import { useCourses } from '@/hooks/useCourses';
import { analyzeSkillGap } from '@/lib/skillAnalysis';
import { Skeleton } from '@/components/ui/skeleton';
import { Map } from 'lucide-react';

export default function CareerRoadmapPage() {
  const { data: profile, isLoading: profileLoading } = useProfile();
  const { data: jobs } = useJobs();
  const { data: courses, isLoading: coursesLoading } = useCourses();

  const userSkills = profile?.current_skills || [];

  // Collect all missing skills from all jobs
  const allMissingSkills = useMemo(() => {
    if (!jobs) return [];
    
    const missing = new Set<string>();
    jobs.forEach((job) => {
      const analysis = analyzeSkillGap(userSkills, job.required_skills || []);
      analysis.missingSkills.forEach((skill) => missing.add(skill));
    });
    
    return Array.from(missing);
  }, [jobs, userSkills]);

  const isLoading = profileLoading || coursesLoading;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Map className="h-6 w-6 text-primary" />
            Career Roadmap
          </h1>
          <p className="text-muted-foreground">
            Your personalized path to career success
          </p>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-[200px] rounded-lg" />
            <div className="grid gap-4 md:grid-cols-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-[150px] rounded-lg" />
              ))}
            </div>
          </div>
        ) : (
          <RoadmapTimeline
            currentSkills={userSkills}
            missingSkills={allMissingSkills}
            courses={courses || []}
            targetJob={profile?.target_role || undefined}
          />
        )}
      </div>
    </DashboardLayout>
  );
}
