import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { KanbanBoard } from '@/components/applications/KanbanBoard';
import { useApplications } from '@/hooks/useApplications';
import { Skeleton } from '@/components/ui/skeleton';
import { ClipboardList } from 'lucide-react';

export default function ApplicationTrackerPage() {
  const { data: applications, isLoading } = useApplications();

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <ClipboardList className="h-6 w-6 text-primary" />
            Application Tracker
          </h1>
          <p className="text-muted-foreground">
            Drag and drop to update your application status
          </p>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="space-y-4">
                <Skeleton className="h-8 w-24" />
                <Skeleton className="h-[200px] rounded-lg" />
              </div>
            ))}
          </div>
        ) : (
          <KanbanBoard applications={applications || []} />
        )}
      </div>
    </DashboardLayout>
  );
}
