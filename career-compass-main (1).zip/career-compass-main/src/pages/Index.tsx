import { Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Compass } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const Index = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="animate-pulse flex items-center gap-3">
          <Compass className="h-8 w-8 animate-spin text-primary" />
          <span className="text-lg">Loading...</span>
        </div>
      </div>
    );
  }

  if (user) {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-br from-background via-background to-secondary">
      {/* Hero Section */}
      <div className="flex flex-1 flex-col items-center justify-center px-4 text-center">
        <div className="mb-8 flex h-20 w-20 items-center justify-center rounded-2xl gradient-primary shadow-lg">
          <Compass className="h-12 w-12 text-primary-foreground" />
        </div>
        
        <h1 className="mb-4 text-5xl font-bold tracking-tight">
          Career <span className="text-primary">GPS</span>
        </h1>
        
        <p className="mb-8 max-w-md text-lg text-muted-foreground">
          Navigate your career journey with confidence. Find jobs, identify skill gaps, 
          and chart your path to success.
        </p>

        <div className="flex gap-4">
          <Link to="/auth">
            <Button size="lg" className="px-8">
              Get Started
            </Button>
          </Link>
          <Link to="/auth">
            <Button size="lg" variant="outline" className="px-8">
              Sign In
            </Button>
          </Link>
        </div>

        {/* Features */}
        <div className="mt-16 grid max-w-4xl gap-8 md:grid-cols-3">
          <div className="rounded-xl bg-card p-6 shadow-card">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
              <span className="text-2xl">🎯</span>
            </div>
            <h3 className="mb-2 font-semibold">Skill Gap Analysis</h3>
            <p className="text-sm text-muted-foreground">
              See exactly which skills you need to land your dream job.
            </p>
          </div>

          <div className="rounded-xl bg-card p-6 shadow-card">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
              <span className="text-2xl">🗺️</span>
            </div>
            <h3 className="mb-2 font-semibold">Career Roadmap</h3>
            <p className="text-sm text-muted-foreground">
              Get personalized course recommendations to bridge the gap.
            </p>
          </div>

          <div className="rounded-xl bg-card p-6 shadow-card">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
              <span className="text-2xl">📋</span>
            </div>
            <h3 className="mb-2 font-semibold">Application Tracker</h3>
            <p className="text-sm text-muted-foreground">
              Track all your applications in one organized Kanban board.
            </p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t py-6 text-center text-sm text-muted-foreground">
        <p>Built for fresh graduates navigating their career journey</p>
      </footer>
    </div>
  );
};

export default Index;
