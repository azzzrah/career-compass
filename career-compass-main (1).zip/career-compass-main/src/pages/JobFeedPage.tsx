import { useState, useMemo } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { JobCard } from '@/components/jobs/JobCard';
import { JobFilter } from '@/components/jobs/JobFilter';
import { useJobs, useJobSources } from '@/hooks/useJobs';
import { useProfile } from '@/hooks/useProfile';
import { useApplications, useCreateApplication } from '@/hooks/useApplications';
import { analyzeSkillGap } from '@/lib/skillAnalysis';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { Briefcase } from 'lucide-react';

export default function JobFeedPage() {
  const [sourceFilter, setSourceFilter] = useState('all');
  const { data: jobs, isLoading: jobsLoading } = useJobs(sourceFilter);
  const { data: sources } = useJobSources();
  const { data: profile } = useProfile();
  const { data: applications } = useApplications();
  const createApplication = useCreateApplication();
  const { toast } = useToast();

  const userSkills = profile?.current_skills || [];
  const appliedJobIds = useMemo(
    () => new Set(applications?.map((a) => a.job_id) || []),
    [applications]
  );

  const handleApply = async (jobId: string) => {
    try {
      await createApplication.mutateAsync(jobId);
      toast({
        title: 'Application submitted!',
        description: 'Your application has been tracked.',
      });
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive',
      });
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Briefcase className="h-6 w-6 text-primary" />
              Job Feed
            </h1>
            <p className="text-muted-foreground">
              Find opportunities that match your skills
            </p>
          </div>
          
          <JobFilter
            sources={sources || []}
            selectedSource={sourceFilter}
            onSourceChange={setSourceFilter}
          />
        </div>

        {jobsLoading ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Skeleton key={i} className="h-[300px] rounded-lg" />
            ))}
          </div>
        ) : jobs && jobs.length > 0 ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {jobs.map((job) => {
              const analysis = analyzeSkillGap(userSkills, job.required_skills || []);
              return (
                <JobCard
                  key={job.id}
                  job={job}
                  analysis={analysis}
                  onApply={handleApply}
                  hasApplied={appliedJobIds.has(job.id)}
                />
              );
            })}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <Briefcase className="h-16 w-16 text-muted-foreground/50 mb-4" />
            <h3 className="text-lg font-medium">No jobs available</h3>
            <p className="text-muted-foreground mt-1">
              Click "Seed Data" in the sidebar to add sample jobs.
            </p>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
